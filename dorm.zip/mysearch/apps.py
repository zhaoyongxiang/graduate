from django.apps import AppConfig


class MysearchConfig(AppConfig):
    name = 'mysearch'
