from haystack import indexes
from system.models import Student


class Studentindex(indexes.SearchIndex, indexes.Indexable):

    text = indexes.CharField(document=True, use_template=True)

    def get_model(self):
        return Student

    def index_queryset(self, using=None):
        return self.get_model().objects.all()

