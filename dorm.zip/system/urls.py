from django.conf.urls import url

from . import views


app_name = "system"

urlpatterns = [
    url(r"^register", views.register, name="register"),
    url(r"^login/$", views.login, name="login"),
    url(r"^code/$", views.code, name="code"),
    url(r"^show/(?P<id>\d+)/$", views.show, name="show"),
    url(r"^reset_pwd/(?P<id>\d+)/$", views.reset_pwd, name="reset_pwd"),
    url(r"^delete/(?P<id>\d+)/$", views.delete, name="delete"),
    url(r"^like/(?P<id>\d+)/$", views.like, name="like"),
    url(r"^update/(?P<id>\d+)/$", views.update, name="update"),
    url(r"^logout/$", views.logout, name="logout"),
    url(r"^change/$", views.change_password, name="change"),
    url(r"^article_add/$", views.article_add, name="article_add"),
    url(r"^notice/(?P<id>\d+)/$", views.notice, name="notice"),
    url(r"^article_details/(?P<id>\d+)/$", views.article_details, name="article_details"),
    url(r"^article_delete/(?P<at_id>\d+)/$", views.article_delete, name="article_delete"),
    url(r"^repair_delete/(?P<at_id>\d+)/$", views.repair_delete, name="repair_delete"),
    url(r"^repair_update/(?P<at_id>\d+)/$", views.repair_update, name="repair_update"),
    url(r"^msg_delete/(?P<at_id>\d+)/$", views.msg_delete, name="msg_delete"),
    url(r"^ajax_all_domain/(?P<dep>\d+)/$", views.ajax_all_domain, name="ajax_all_domain"),
    url(r"^article_list/$", views.article_list, name="article_list"),
    url(r"^change_password/$", views.change_password, name="change_password"),
    # url(r"^user_list/$", views.user_list, name="user_list"),

    url(r"^list/$", views.list, name="list"),
    # url(r"^repair_list/$", views.repair_list, name="repair_list"),
    # url(r"^msg_list/$", views.msg_list, name="msg_list"),
    url(r"^self_article/$", views.self_article, name="self_article"),
    url(r"^self_repair/$", views.self_repair, name="self_repair"),
    url(r"^repair_add/$", views.repair_add, name="repair_add"),
    url(r"^msg_add/$", views.msg_add, name="msg_add"),
    url(r"^query/$", views.query, name="query"),


]

