import xadmin
from xadmin import views

from . import models


xadmin.site.register(models.Student)
xadmin.site.register(models.Article)
xadmin.site.register(models.major)
xadmin.site.register(models.Msg)
xadmin.site.register(models.repair)
xadmin.site.register(models.department)
xadmin.site.register(models.Administrator)


class BaseSetting(object):
    enable_themes = True
    use_bootswatch = True


xadmin.site.register(views.BaseAdminView, BaseSetting)


class GlobalSettings(object):
    site_title = "宿舍管理系统"
    site_footer = "郑州工业应用技术学院"
    menu_style = "accordion"


xadmin.site.register(views.CommAdminView, GlobalSettings)
