from django.db import models
from DjangoUeditor.models import UEditorField


# 管理员表
class Administrator(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="用户编号")
    username = models.CharField(max_length=200, unique=True, verbose_name="用户账号")
    password = models.CharField(max_length=50, verbose_name="用户密码")

    class Meta:
        verbose_name_plural = '管理员'

    def __str__(self):
        return self.username


# 公共信息表
class Msg(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="编号")
    title = models.CharField(max_length=200, verbose_name="公告标题")
    content = UEditorField(verbose_name="公告内容")
    publish_time = models.DateTimeField(auto_now_add=True, null=True, verbose_name="创建时间")
    author = models.ForeignKey(Administrator, on_delete=models.CASCADE, verbose_name="发布人：管理员")

    class Meta:
        ordering = ["-publish_time", "id"]
        verbose_name_plural = '公告'

    def __str__(self):
        return self.title


# 系别管理
class department(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="编号")
    name = models.CharField(max_length=200, default="", unique=True, verbose_name="学院名称")

    class Meta:
        verbose_name_plural = '学院信息'

    def __str__(self):
        return self.name


# 专业管理
class major(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="编号")
    name = models.CharField(max_length=200, default="", unique=True, verbose_name="专业名称")
    department = models.ForeignKey(department, on_delete=models.CASCADE, null=True, verbose_name="所属院系")

    class Meta:
        verbose_name_plural = '专业信息'

    def __str__(self):
        return self.name


# 学生管理
class Student(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="学生编号")
    name = models.CharField(max_length=200, unique=True, verbose_name="用户账号")
    nickname = models.CharField(max_length=255, null=True, verbose_name="用户昵称")
    # 用户头像
    avatar = models.ImageField(upload_to='static/img/upload', default="static/img/timg.jpg", verbose_name="用户头像")
    password = models.CharField(max_length=50, verbose_name="用户密码")
    age = models.IntegerField(default=18, verbose_name="用户年龄")
    gender = models.CharField(max_length=10, default="男", verbose_name="用户性别")
    # 宿舍详情
    dorm_name = models.CharField(max_length=200, default="未设置", verbose_name="宿舍楼名称")
    dorm_number = models.IntegerField(default="1111", verbose_name="宿舍号，1234代表东西南北")
    teacher = models.CharField(max_length=50, default="未设置", verbose_name="辅导员")
    admin = models.CharField(max_length=50, default="未设置", verbose_name="寝室长")
    # 专业
    major = models.ForeignKey(major, on_delete=models.CASCADE, null=True, verbose_name="学院信息")

    class Meta:
        verbose_name_plural = '学生信息'

    def __str__(self):
        return self.name


# 水电费
class charge(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="用户编号")
    electric = models.CharField(max_length=200, default=0, verbose_name="用电量")
    cost = models.CharField(max_length=200, default=0, verbose_name="应交费用")
    dormitory = models.ForeignKey(Student, on_delete=models.CASCADE, null=True, verbose_name="宿舍信息")


# 报修管理
class repair(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="编号")
    title = models.CharField(max_length=200, default="", verbose_name="宿舍详情")
    content = UEditorField(verbose_name="报修内容")
    publish_time = models.DateTimeField(auto_now_add=True, null=True, verbose_name="创建时间")
    case = models.CharField(max_length=200, default="已报修", verbose_name="维修进度")
    author = models.ForeignKey(Student, on_delete=models.CASCADE, null=True, verbose_name="报修人信息")

    class Meta:
        ordering = ["-publish_time", "id"]
        verbose_name_plural = '报修管理'

    def __str__(self):

        return self.author.dorm_name


# 文章
class Article(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="文章编号")
    content =UEditorField(verbose_name="文章内容")
    cont = models.IntegerField(default=0, verbose_name="点赞人数")
    publish_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    author = models.ForeignKey(Student, on_delete=models.CASCADE, null=True, verbose_name="外键")

    class Meta:
        ordering = ["-publish_time", "id"]
        verbose_name_plural = '留言板'

    def __str__(self):
        return self.content

