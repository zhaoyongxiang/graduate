﻿from django.shortcuts import render, redirect, reverse
from io import BytesIO
from django.http import HttpResponse
from . import models
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST, require_http_methods, require_safe
from django.core.serializers import serialize
from django.http import JsonResponse
from . import apply
import logging
# 分页
from django.core.paginator import Paginator
from django.conf import settings


# ajax的使用登录验证账号和密码
# @require_POST
# @csrf_exempt
# def check_login(request):
#     username = request.POST["username"]
#     password = request.POST["password"]
#     print("阿打算大撒多")
#     # print(username)
#     try:
#         user = models.Student.objects.get(name=username)
#         if password != user.password:
#             return JsonResponse({"msg": "账号或密码错误", "is_success": False})
#         else:
#             return JsonResponse({"msg": "请登录", "is_success": True})
#
#     except:
#
#         return JsonResponse({"msg": "账号或密码错误", "is_success": False})


# ajax 在用户列表中的使用

#
# def user_list(request):
#     users = models.Student.objects.all()
#     users = serialize("json", users)
#     print(users)
#     return HttpResponse(users)


# 注册注册
def register(request):
    if request.method == "GET":
        return render(request, "system/register.html", {"msg": "请认填写以下问题"})

    elif request.method == "POST":
        name = request.POST["username"]
        password = request.POST["password"]
        password1 = request.POST["password1"]
        print("你好呀")

    # TODO 验证码

    # 数据校验
    # print(name)
    # print(password)
    if name == "":
        return render(request, "system/register.html", {"msg": "用户名不能为空"})

    if len(password) < 2:
        return render(request, "system/register.html", {"msg": "密码不能小于2位"})

    if password != password1:
        return render(request, "system/register.html", {"msg": "两次密码不一致！！"})
        # 用户名称是否存在
    users = models.Student.objects.filter(name=name)
    if len(users) > 0:
        return render(request, "system/register.html", {"msg": "该用户名称已存在，请重新注册！！"})

    # 验证码
    code = request.POST["code"].strip()
    print(code)
    msg = request.session["code"]
    print(msg)

    if code.lower() != msg.lower():
        return render(request, "system/register.html", {"msg": "验证码错误，请重新注册！！"})

    try:
        # 添加用户
        newpwd = apply.pwd_by_hmac(password)
        # print("可可可可")
        user = models.Student(name=name, password=newpwd)
        user.save()
        return render(request, "system/login.html", {"msg": "注册成功，请登录"})
    except Exception as e:
        print("出现错误", e)
        return render(request, "system/register.html", {"msg": "注册失败, 请重新注册"})


# 登录

def login(request):
    if request.method == "GET":
        # 注册页面
        context = {"msg": "填写下面"}
        return render(request, "system/login.html", context)
    elif request.method == "POST":
        print("哟哟哟哟哟哟")

        username = request.POST["username"]
        password = request.POST["password"]
        print("账号为：", username)
        print("密码为：", password)
        # 登录用户身份
        who = request.POST["who"]
        print(type(who), who)

        if username.strip() == "":
            return render(request, "system/login.html", {"msg": "用户名不能为空"})
        if len(password.strip()) < 3:
            return render(request, "system/login.html", {"msg": "密码不能小于3位"})

        try:
            # 缓存区登录
            if who == "1":
                user = apply.get_login_users(username)
                pwd = apply.pwd_by_hmac(password)

            if who == "2":
                print("管理员登录了1")
                pwd = password
                user = models.Administrator.objects.get(username=username)
                print("管理员登录了2")
            # 验证码
            code = request.POST.get("code", None)
            count = request.session.get("login_error", 0)

            if count >= 2:
                print(code)
                msg = request.session["code"]
                print(msg)

                if code.lower() != msg.lower():
                    return render(request, "system/login.html", {"msg": "验证码错误，请重新登录！！"})

            if pwd == user.password:
                request.session["loginUser"] = user
                request.session["login_error"] = 0
                request.session["number"] = "0"

                # return render(request, "system:article_list")
                return redirect(reverse("system:article_list"))

            else:
                print("错误：")

                print(count)
                count += 1
                request.session["login_error"] = count

                return render(request, "system/login.html", {"msg": "账号或密码错误"})

        except Exception as e:
            print("错误：", e)
            count = request.session.get("login_error", 0)
            print(count)
            count += 1
            request.session["login_error"] = count

            return render(request, "system/login.html", {"msg": "登录超时"})


# 重置密码
@apply.verify
def reset_pwd(request, id):
    user = models.Student.objects.get(pk=id)
    print(user.password)
    pwd = apply.pwd_by_hmac("123456")
    print(pwd)
    user.password = pwd
    user.save()
    return render(request, "system/success.html", {"msg": "密码重置成功,初始密码为123456"})


# 列表显示
@apply.verify
def list(request):
    try:
        users = models.Student.objects.all()
        pageSize = settings.PAGE_SIZE
        paginator = Paginator(users, pageSize)
        pageNow = request.GET.get("pageNow", 1)
        page = paginator.page(pageNow)

        # msg = "你看这个碗，它又大又圆"
        return render(request, "system/users_list.html", {"page": page})
    except Exception as e:
        print("出现错误，", e)
        return render(request, "system/users_list.html")


# 验证码
def code(request):
    """
     验证码的视图函数
     :param request:
     :return:
     """
    img, msg = apply.create_code()
    file = BytesIO()
    img.save(file, "PNG")
    # 将验证码存入session
    request.session["code"] = msg
    print("哟哟哟，鸟瞰智能和")
    return HttpResponse(file.getvalue(), 'image/png')


# 详情页面
@apply.verify
def show(request, id):
    user = models.Student.objects.get(pk=id)
    return render(request, "system/show.html", {"user": user})


# 更新用户信息
@apply.verify
def update(request, id):
    user = models.Student.objects.get(id=id)
    if request.method == "GET":
        academy = models.department.objects.all()
        # return render(request, "system/update.html", {"user": user, "academy": academy})
        return render(request, "system/update.html", {"user": user, "academy": academy})
    else:
        # 用户头像
        avatar = request.FILES.get('avatar', 'static/img/bg1.png')
        # 用户 年龄
        age = request.POST["age"]
        # 用户性别
        gender = request.POST["gender"]
        #  用户姓名
        nickname = request.POST["nickname"]

        # 宿舍名称
        dorm_name = request.POST["dorm_name"]
        # 宿舍号
        dorm_number = request.POST["dorm_number"]
        # 辅导员
        teacher = request.POST["teacher"]
        # 寝室长
        admin = request.POST["admin"]
        # 寝室情况
        user.dorm_name = dorm_name
        user.dorm_number = dorm_number
        user.teacher = teacher
        user.admin = admin
        # 学院信息
        # department = request.POST["department"]
        # print(department)

        # 学院
        # college = models.department.objects.get(name=department)
        # # college = models.department(name=department)
        # # college.save()
        # # 专业信息
        try:
            major_name = request.POST["major"]
            # print(major_name)
            # print(major_name)
            major = models.major.objects.get(pk=major_name)

        except Exception as e:
            print("发现错误", e)
            return render(request, "system/update.html", {"user": user, "msg": "学院信息不能为空！！"})

        # 用户信息
        user.age = age
        user.gender = gender
        user.nickname = nickname
        user.save()
        # 宿舍信息
        # user.dormitory = dorm
        # 专业信息
        user.major = major
        print("adadsadas")
        if avatar != "static/img/bg1.png":
            user.avatar = avatar
            # print(avatar)
            print('头像更新成功')

        try:
            user.save()
            if user.name == request.session["loginUser"].name:
                # del request.session["loginUser"]

                # major_all = models.major.objects.all()

                # print(academy)
                request.session["loginUser"] = user
            # return redirect(reverse("system:index"))
            return render(request, "system/show.html", {"user": user,  "msg": "修改成功"})
        except Exception as e:
            print("发现错误，错误信息是：", e)
            return render(request, "system/update.html", {"user": user, "msg": "修改失败，请重新修改！！"})


# 专业
def ajax_all_domain(request, dep):
    # 获取学院对应的字段
    print(dep)
    try:
        department = models.department.objects.get(id=dep)
        major = models.major.objects.filter(department=department.id)

        major = serialize("json", major)
        print(major)
        # return JsonResponse({"domains": domains, "issuccess": True})
        # return JsonResponse(domains,safe=False)
        return HttpResponse(major)
    except Exception as e:
        print("没有找到", e)
        return JsonResponse({"major": major, "issuccess": False})


# 删除用户
@apply.verify
def delete(request, id):
    # print(id)
    # try:
    #     request.session["loginUser"]
    # except:
    #     return render(request, "blog/login.html", {"msg": "请先登录"})
    try:
        user = models.Student.objects.get(id=id)
        user.delete()
        # del request.session["loginUser"]
        return redirect(reverse("system:list"))

    except Exception as e:
        print("错误：", e)
        return render(request, "system/list.html",  {"msg": "删除失败，请重新删除"})


@apply.verify
# 退出登录
def logout(request):
    try:
        del request.session["loginUser"]
        return redirect(reverse("system:login"))
    except Exception as e:
        print("错误信息：", e)
        return redirect(reverse("system:list"))


# 修改密码
@apply.verify
def change_password(request):
    user = request.session["loginUser"]
    if request.method == "GET":
        return render(request, "system/change_password.html", {"user": user})
    else:
        password = request.POST["password"]
        password1 = request.POST["password1"]
        password2 = request.POST["password2"]
        try:
            if user.age:
                if user.password == apply.pwd_by_hmac(password) and password1 == password2:
                    pwd = apply.pwd_by_hmac(password1)
                    user.password = pwd
                    user.save()
                    print("哇啊娃娃")
                    return render(request, "system/login.html")
                else:
                    return render(request, "system/change_password.html", {"msg": "修改失败，请重新输入"})

        except Exception as e:
            if user.password == password and password1 == password2:
                user.password = password1
                user.save()
                print("管理员密码修改成功")
                return render(request, "system/login.html")
            else:
                return render(request, "system/change_password.html", {"msg": "修改失败，请重新输入"})


# 文章列表
# @require_GET
@apply.verify
def article_list(request):
    try:
        print("列表呀丫丫丫啊")
        number = request.session["number"]
        # print(type(number))
        # print(number)
        pageSize = settings.PAGE_SIZE
        print("每页显示页码", pageSize)

        if request.session["number"] == "0":
            articles = models.Msg.objects.all()
            # 分页设置
            paginator = Paginator(articles, pageSize)
            pageNow = request.GET.get("pageNow", 1)
            page = paginator.page(pageNow)
            print("拉阿拉啦啦")

            # return render(request, "system/msg_list.html", {"articles": articles})
            return render(request, "system/msg_list.html", {"page": page})

        if request.session["number"] == "3" or request.session["number"] == 3:
            articles = models.repair.objects.all()
            paginator = Paginator(articles, pageSize)
            pageNow = request.GET.get("pageNow", 1)
            page = paginator.page(pageNow)
            print("维修呀")
            return render(request, "system/repair_list.html", {"page": page})

        if request.session["number"] == "4":
            articles = models.Article.objects.all()
            paginator = Paginator(articles, pageSize)
            pageNow = request.GET.get("pageNow", 1)
            page = paginator.page(pageNow)
            return render(request, "system/article_list.html", {"page": page})

    except Exception as e:
        print("出现错误，信息为", e)
        return render(request, "system/msg_list.html")


# 文章详情
@apply.verify
def article_details(request, at_id):
    if request.session["number"] == "3":
        # at = models.repair(content=content, author=auth)
        at = models.repair.objects.get(id=at_id)
        # print("删除维修")
        # at.delete()
    if request.session["number"] == "4":
        at = models.Article.objects.get(id=at_id)
        # print("删除留言")
        # at.delete()

    # at = models.Article.objects.get(pk=at_id)
    # print(at.id)
    return render(request, "system/article_details.html", {"article": at})


# 创建文章
@apply.verify
def article_add(request):
    if request.method == "GET":

        return render(request, "system/article_add.html")

    else:
        try:
            auth = request.session["loginUser"]
            if auth:
                content = request.POST["content"].strip()
                if content == "":
                    return render(request, "system/article_add.html", {"msg": "内容不能为空"})
                # 保存动态

                if request.session["number"] == "4":
                    at = models.Article(content=content, author=auth)
                    at.save()
                    print("已留言")
                return JsonResponse({"msg": "文章添加成功！！", "success": True})
        except:

            return JsonResponse({"msg": "文章添加失败！！", "success": False})


# 创建维修单
@apply.verify
def repair_add(request):
    if request.method == "GET":

        return render(request, "system/repair_add.html")

    else:
        try:
            auth = request.session["loginUser"]
            if auth:
                content = request.POST["content"].strip()
                title = auth.dorm_number
                if content == "":
                    return render(request, "system/repair_add.html", {"msg": "内容不能为空"})
                at = models.repair(content=content, author=auth, title=title)
                print("已添加维修单")
                at.save()

                return JsonResponse({"msg": "维修单添加成功！！", "success": True})

        except:

            return JsonResponse({"msg": "维修单添加失败！！", "success": False})


# 修改报修状态
def repair_update(request, at_id):

    repair = models.repair.objects.get(id=at_id)
    if request.method == "GET":

        return render(request, "system/repair_update.html", {"repair": repair})

    else:
        try:
            print("更新进度了")
            state = request.POST.get("state")
            print(state)
            repair.case = state
            repair.save()
            return redirect(reverse("system:article_list"))

        except Exception as e:

            print("修改出错了，错误信息为：", e)

            return render(request, "system/repair_update.html")


# 添加公告
def msg_add(request):
    if request.method == "GET":

        return render(request, "system/msg_add.html")

    else:
        try:
            auth = request.session["loginUser"]
            print("添加公告啦")
            if auth:
                title = request.POST["title"].strip()
                print(title)
                content = request.POST["content"].strip()
                if content == "" or title == "":
                    return render(request, "system/msg_add.html", {"msg": "内容不能为空"})
                # 保存动态

                at = models.Msg(title=title, content=content, author=auth)
                print("已添加公告")
                at.save()
                return JsonResponse({"msg": "公告添加成功！！", "success": True})
        except Exception as e:
            print("错误", e)

            return JsonResponse({"msg": "公告添加失败！！", "success": False})


# 删除留言
@apply.verify
def article_delete(request, at_id):
    print(at_id)
    try:
            at = models.Article.objects.get(id=at_id)
            print("删除留言")
            at.delete()
            # return render(request, "system/article_list.html")
            return redirect(reverse("system:article_list"))
    except Exception as e:
        print("错误：", e)
        return redirect(reverse("system:login"))


# 删除报修单
@apply.verify
def repair_delete(request, at_id):
    print(at_id)
    try:
        at = models.repair.objects.get(id=at_id)
        print("删除维修单")
        at.delete()
        # request.session["number"] = "3"
        return redirect(reverse("system:article_list"))

    except Exception as e:
        print("出现错误", e)
        return redirect(reverse("system:article_list"))


# 删除公告
@apply.verify
def msg_delete(request, at_id):
    print(at_id)
    try:
            at = models.Msg.objects.get(id=at_id)
            print("删除留言")
            at.delete()
            return redirect(reverse("system:article_list"))

    except Exception as e:
       print("出现错误", e)
       return redirect(reverse("system:article_list"))


# 电费查询
def charge(requset):
    pass


# 查询统计
def find(request):

    if request.method == "GET":
        return render(request, "system/find.html")

    else:
        pass


@apply.verify
# 个人动态
def self_article(request):
    articles = models.Article.objects.filter(author=request.session["loginUser"]).order_by("-publish_time")
    # 分页
    pageSize = settings.PAGE_SIZE
    paginator = Paginator(articles, pageSize)
    pageNow = request.GET.get("pageNow", 1)
    page = paginator.page(pageNow)
    print("维修呀")

    return render(request, "system/self_article.html", {"page": page})


# 个人报修表
@apply.verify
def self_repair(request):
    articles = models.repair.objects.filter(author=request.session["loginUser"]).order_by("-publish_time")
    request.session["number"] = 3
    pageSize = settings.PAGE_SIZE
    paginator = Paginator(articles, pageSize)
    pageNow = request.GET.get("pageNow", 1)
    page = paginator.page(pageNow)
    # print("一样一样")
    # msg = "你看这个碗，它又大又圆"
    return render(request, "system/self_repair.html", {"page": page})


# 点赞
@apply.verify
def like(request, id):
    # articles = models.Article.objects.all().order_by("-publish_time")
    article = models.Article.objects.get(pk=id)
    print(article.cont)
    article.cont += 1
    article.save()

    return redirect(reverse("system:article_list"))


# 摘要
# def abstract(cotent):
    # content = re.findall(r">(.*?)<", )


# 公告
@apply.verify
def notice(request, id):
    print(type(id))
    request.session["number"] = id
    if id == "0":
        print("公告栏")
        return redirect(reverse("system:article_list"))
    if id == "1":
        print("用户列表呀")
        return redirect(reverse("system:list"))
    if id == "2":
        return redirect(reverse("system:query"))
    if id == "3":
        return redirect(reverse("system:article_list"))
    if id == "4":
        return redirect(reverse("system:article_list"))


#
def query(request):
    return render(request, 'system/query.html')
