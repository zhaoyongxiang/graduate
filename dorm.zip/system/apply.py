import hashlib
import hmac
import random, string
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from django.shortcuts import render
from django.core.cache import cache
from . import models

# 可以存储在setting文件中，调用时用 from django.conf import settings


# 验证码是否登录
def verify(fn):
    # print("进入装饰器")

    def inner(request, *args, **kwargs):
        login_user = request.session.get("loginUser", None)
        if login_user is not None:
            print("已登录")
            return fn(request, *args, **kwargs)

        else:
            print("未登录")
            return render(request, "system/login.html", {"msg": "登录后才可访问"})

    return inner


# 密码加密
def pwd_by_hashlib(password):
    """
    密码加密，使用hashlib
    :param password:
    :return:
    """
    # 转码
    md5 = hashlib.md5(password.encode("utf-8"))
    md5.update("1呀-哈)2哈".encode("utf-8"))
    return md5.hexdigest()


# 对称加密

def pwd_by_hmac(password):
    """
    密码加密，使用hmac
    :param password:
    :return:
    """
    # 转码

    return hmac.new("yo123h".encode("utf-8"), password.encode("utf-8"), "MD5").hexdigest()


# 验证码
def get_Random_Char(count=4):
    # 生成随机字符串
    #  string 模块包含各种字符串，以下为小写字母加数字
    ran = string.ascii_lowercase + string.digits + string.ascii_uppercase
    char = ''
    for i in range(count):
        char += random.choice(ran)
    return char


# 获取随机颜色
def get_random_color():
    return random.randint(200, 255), random.randint(200, 255), random.randint(200, 255)


# 创建图片
def create_code():
    # 创建图片模式，大小，背景色
    img = Image.new("RGB", (120, 32), (66, 88, 56))
    # 创建画布
    draw = ImageDraw.Draw(img)
    # 设置字体
    font = ImageFont.truetype('arial.ttf', 25)

    #  获得验证码
    code = get_Random_Char()
    # request.session["code"] = code

    # 将字符换在画布上
    for t in range(4):
        draw.text((30*t + 5, 0), code[t], get_random_color(), font)

    # 生成干扰点
    for _ in range(random.randint(0, 50)):
        # 位置，颜色
        draw.point((random.randint(0, 120), random.randint(0, 30)), fill=get_random_color())

    # 图片模糊
    img = img.filter(ImageFilter.BLUR)
    # 保存图片
    # img.save(''.join(code)+'.jpg', 'jpeg')
    return img, code


# # 缓存文章
# def get_all_article(request, is_change=False):
#     print("从缓存中获取数据")
#     articles = cache.get("all_article")
#     if articles is None or is_change:
#         print("从数据库中获取数据")
#         if request.session["number"] is None or request.session["number"] == 0:
#             articles = models.Msg.objects.all()
#
#         elif request.session["number"] == 1:
#             articles = models.Student.objects.all()
#
#         elif request.session["number"] == 2:
#             articles = models.charge.objects.all()
#
#         elif request.session["number"] == 3:
#             articles = models.repair.objects.all()
#
#         elif request.session["number"] == 4:
#             articles = models.Article.objects.all()
#
#         elif request.session["number"] == 5:
#             pass
#
#         print("数据存入数据库中")
#         cache.set("all_article", articles)
#
#     return articles


# 缓存登录用户
def get_login_users(name, is_change=False):
    # print("从缓存中登录")
    users = cache.get("{}".format(name))
    if users is None or is_change:
        # print("从数据库中登录")
        users = models.Student.objects.get(name="{}".format(name))
        # print("数据存入数据库中")
        cache.set("{}".format(name), users)

    return users
#

# if __name__ == '__main__':
#     a = pwd_by_hmac("123")
#     print(a)
